#ifndef SIMULACRO_SO_MAIN_H
#define SIMULACRO_SO_MAIN_H

#include "semaforo.h"
#include "interface.h"
#include "globals.h"
#include "cpu.h"

#include <malloc.h>
#include <stdbool.h>
#include <locale.h>
#include <unistd.h>
#include <pthread.h>

#endif //SIMULACRO_SO_MAIN_H